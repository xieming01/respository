import Head from './head.js';
import User from './user';
import RegistrationForm from './userSetting'
import AlertManage from '../AlertManage';
export { Head, User, RegistrationForm, AlertManage};