export const Login_STARTED = 'Login/REQ_STARTED';
export const Login_SUCCESS = 'Login/REQ_SUCCESS';
export const Login_FAILURE = 'Login/REQ_FAILURE';