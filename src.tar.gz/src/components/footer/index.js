import Footer from './footer';
export {Footer}