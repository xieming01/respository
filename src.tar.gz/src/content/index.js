import About from './About/About.js';
import Article from './Article';
import Home from './Home/home.js';
import Resource from './Resource/Resource.js';
import HomeDetail from './Home/detail';

export { About, Article, Home, Resource, HomeDetail}